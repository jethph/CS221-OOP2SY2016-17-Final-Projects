/**
 * @(#)ProjectDemo.java
 *
 * Bryle John Ballon, Jasper Fatalla
 *
 * BSCS-IIB 
 * @version 1.00 2017/3/5
 */


public class ProjectDemo extends MainForm
{

	public static void main(String[] args)
	{
		MainForm myForm = new MainForm();
		myForm.setVisible(true);
	}
}